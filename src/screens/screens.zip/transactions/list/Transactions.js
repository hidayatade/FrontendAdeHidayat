import React, {Component} from 'react';
import {RefreshControl, Alert} from 'react-native';
import {
  Container,
  Text,
  ListItem,
  Body,
  Right,
  Icon,
  View,
  Fab,
  Button,
  Item,
  Input,
} from 'native-base';
import {CommonHeader} from '../../../components/CommonHeader';
import styles from './styles';
import {connect} from 'react-redux';
import {findAll, deleteById} from '../../../actions/transactions';
import showError from '../../../utils/toast';
import {SwipeListView} from 'react-native-swipe-list-view';

function RowTransaction({onPress, item}) {
  return (
    <ListItem style={styles.item} onPress={() => onPress(item)}>
      <Body>
        <Text>{item.amount}</Text>
      </Body>
      <Body>
        <Text>{item.type}</Text>
      </Body>
      <Body>
        <Text>{item.description}</Text>
      </Body>
      <Right>
        <Icon name="ios-arrow-forward" />
      </Right>
    </ListItem>
  );
}

class Transactions extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      total: 0,
      search: '',
      params: {
        search: '',
        sort: 'asc',
        page: 0,
      },
    };
  }

  componentDidMount = () => {
    this.reload(this.state.params);
  };

  componentDidUpdate(prevProps, prevState) {
    const {deletedData, deletedError, savedData, data, error} = this.props;
    console.log('data', data);
    if (prevProps.data !== data) {
      this.setState({
        data: [...this.state.data, ...data.list],
        total: data.total,
        search: this.state.params.search,
        params: {
          ...this.state.params,
          page: data.page,
        },
      });
    } else if (
      prevProps.deletedData !== deletedData ||
      prevProps.savedData !== savedData
    ) {
      this.onRefresh();
    } else if (error && prevProps.error !== error) {
      showError(error);
    } else if (deletedError && prevProps.deletedError !== deletedError) {
      showError(deletedError);
    }
  }

  reload({search, sort = 'asc', page = 0} = {}) {
    this.props.findAll({search: {name: search}, sort, page});
  }

  onRefresh = () => {
    const {params} = this.state;
    this.setState(
      {
        data: [],
        total: 0,
        params: {...params, page: 0},
      },
      () => this.reload(this.state.params),
    );
  };

  onAdd = () => {
    this.props.navigation.navigate('TransactionDetail');
  };

  onShowForm = transaction => {
    this.props.navigation.navigate(
      'TransactionDetail',
      transaction ? {id: transaction.id} : null,
    );
  };

  onDelete = transaction => {
    Alert.alert('Confirmation', 'Delete this transaction?', [
      {
        text: 'Cancel',
        style: 'cancel',
      },
      {
        text: 'Ok',
        onPress: () => this.props.deleteById(transaction.id),
      },
    ]);
  };

  onSearch = () => {
    const {search, params} = this.state;
    this.setState(
      {
        data: [],
        total: 0,
        params: {...params, search: search, page: 0},
      },
      () => this.reload(this.state.params),
    );
  };

  onEndReadChed = () => {
    const {data, total, params} = this.state;
    if (data.length < total) {
      this.reload({
        ...params,
        page: params.page + 1,
      });
    }
  };

  render() {
    const {navigation, loading} = this.props;
    const {data, search} = this.state;

    return (
      <Container>
        <CommonHeader navigation={navigation} title="Transactions" />
        <View style={styles.content}>
          <Item>
            <Input
              placeholder="Search"
              value={search}
              onChangeText={search => this.setState({search})}
            />
            <Button transparent onPress={this.onSearch}>
              <Icon name="search" />
            </Button>
          </Item>
          <SwipeListView
            refreshControl={
              <RefreshControl refreshing={loading} onRefresh={this.onRefresh} />
            }
            data={data}
            renderItem={({item}) => (
              <RowTransaction onPress={this.onShowForm} item={item} />
            )}
            renderHiddenItem={data => (
              <View style={styles.hiddenItem}>
                <Button danger onPress={() => this.onDelete(data.item)}>
                  <Icon name="md-trash" />
                </Button>
              </View>
            )}
            leftOpenValue={75}
            rightOpenValue={-75}
            keyExtractor={transaction => transaction.id.toString()}
            onEndReached={this.onEndReached}
            onEndReachedThreshold={0.5}
          />
          <Fab onPress={this.onShowForm}>
            <Icon name="add" />
          </Fab>
        </View>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  deletedData: state.deleteTransactionById.data,
  deletedError: state.deleteTransactionById.error,
  savedData: state.savedTransaction.data,
  data: state.transactions.data,
  loading: state.transactions.loading || state.deleteTransactionById.loading,
  error: state.transactions.error,
});

const mapDispatchToProps = {
  findAll,
  deleteById,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Transactions);
