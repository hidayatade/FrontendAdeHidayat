import React, {Component} from 'react';
import {
  Container,
  Text,
  Content,
  Form,
  Item,
  Input,
  Label,
  Picker,
  Button,
  Icon,
} from 'native-base';
import {View} from 'react-native';
import {CommonHeader} from '../../../components/CommonHeader';
import styles from './styles';
import {connect} from 'react-redux';
import {save, findById} from '../../../actions/transactions';
import {showError} from '../../../utils/toast';

class TransactionScreen extends Component {
  constructor(props) {
    super(props);

    const {route} = this.props;
    this.state = {
      id: route.params?.id,
      amount: '',
      type: '',
      description: '',
    };
  }

  componentDidMount = () => {
    const {id} = this.state;
    if (id) {
      this.props.findById(this.state.id);
    }
  };

  componentDidUpdate(prevProps, prevState) {
    const {navigation, data, savedData, savedError, error} = this.props;
    if (prevProps.data !== data) {
      this.setState({...data});
    } else if (prevProps.savedData !== savedData) {
      navigation.goBack();
    } else if (error && prevProps.error !== error) {
      showError(error);
    } else if (savedError && prevProps.savedError !== savedError) {
      showError(savedError);
    }
  }

  onChange = (name, value) => {
    this.setState({[name]: value});
  };

  onSubmit = () => {
    this.props.save(this.state);
  };

  render() {
    const {navigation, loading, savedError} = this.props;
    const {id, amount, type, description} = this.state;
    const errorData = savedError?.data || {};
    return (
      <Container>
        <CommonHeader navigation={navigation} title="Transactions" />

        <Content>
          <Form>
            {id && (
              <Item floatingLabel>
                <Label>ID</Label>
                <Input style={styles.input} disabled value={id.toString()} />
              </Item>
            )}
            <View>
              <Item floatingLabel error={errorData?.amount != null}>
                <Label>Amount</Label>
                <Input
                  style={styles.input}
                  value={amount.toString()}
                  onChangeText={value => this.onChange('amount', value)}
                />
              </Item>
              {errorData?.amount && (
                <Text style={styles.error}>{errorData?.amount[0]}</Text>
              )}
            </View>
            <Item>
              <Label>Type</Label>
              <Picker
                mode="dropdown"
                style={styles.picker}
                iosIcon={<Icon name="arrow-down" />}
                selectedValue={type}
                onValueChange={selectedValue =>
                  this.onChange('type', selectedValue)
                }>
                <Picker.Item label="Select type" disabled />
                <Picker.Item label="PURCHASE" value="PURCHASE" />
                <Picker.Item label="SELL" value="SELL" />
                <Picker.Item label="PAY SALARY" value="PAYSALARY" />
              </Picker>
            </Item>
            {errorData?.type && (
              <Text style={styles.error}>{errorData?.type[0]}</Text>
            )}
            <View>
              <Item floatingLabel error={errorData?.description != null}>
                <Label>Description</Label>
                <Input
                  style={styles.input}
                  value={description}
                  onChangeText={value => this.onChange('description', value)}
                />
              </Item>
              {errorData?.description && (
                <Text style={styles.error}>{errorData?.description[0]}</Text>
              )}
            </View>
            <Button
              rounded
              style={styles.button}
              onPress={this.onSubmit}
              disabled={loading}>
              <Text style={styles.buttonText}>S a v e</Text>
            </Button>
          </Form>
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  savedData: state.savedTransaction.data,
  savedError: state.savedTransaction.error,
  data: state.transactionById.data,
  loading: state.transactionById.loading || state.savedTransaction.loading,
  error: state.transactionById.error,
});

const mapDispatchToProps = {
  save,
  findById,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(TransactionScreen);
