import React, {Component} from 'react';
import {RefreshControl} from 'react-native';
import {
  Container,
  Text,
  ListItem,
  Body,
  Right,
  Icon,
  View,
  Fab,
  Button,
  Item,
  Input,
} from 'native-base';
import {CommonHeader} from '../../../components/CommonHeader';
import {connect} from 'react-redux';
import {findSummary} from '../../../actions/transactions';
import showError from '../../../utils/toast';
import {SwipeListView} from 'react-native-swipe-list-view';
import styles from './style';

function RowTransactionSummary({summary}) {
  return (
    <ListItem style={styles.item}>
      <Body>
        <Text>{summary.amount}</Text>
      </Body>
      <Body>
        <Text>{summary.type}</Text>
      </Body>
      <Body>
        <Text>{summary.description}</Text>
      </Body>
      <Right>
        <Icon name="ios-arrow-forward" />
      </Right>
    </ListItem>
  );
}

class TransactionSummary extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      total: 0,
      search: '',
      params: {
        search: '',
        sort: 'asc',
        page: 0,
      },
    };
  }

  componentDidMount = () => {
    this.reload(this.state.params);
  };

  componentDidUpdate(prevProps, prevState) {
    const {data, error} = this.props;
    console.log('data', data);
    if (prevProps.data !== data) {
      this.setState({
        data: [...this.state.data, ...data],
        total: data.total,
        search: this.state.params.search,
        params: {
          ...this.state.params,
          page: data.page,
        },
      });
    } else if (error && prevProps.error !== error) {
      showError(error);
    }
  }

  reload({search, sort = 'asc', page = 0} = {}) {
    this.props.findSummary({search: {name: search}, sort, page});
  }

  onRefresh = () => {
    const {params} = this.state;
    this.setState(
      {
        data: [],
        total: 0,
        params: {...params, page: 0},
      },
      () => this.reload(this.state.params),
    );
  };

  onSearch = () => {
    const {search, params} = this.state;
    this.setState(
      {
        data: [],
        total: 0,
        params: {...params, search: search, page: 0},
      },
      () => this.reload(this.state.params),
    );
  };

  onEndReadChed = () => {
    const {data, total, params} = this.state;
    if (data.length < total) {
      this.reload({
        ...params,
        page: params.page + 1,
      });
    }
  };

  render() {
    const {navigation, loading} = this.props;
    const {data, search} = this.state;

    return (
      <Container>
        <CommonHeader navigation={navigation} title="Transactions" />
        <View style={styles.content}>
          <Item>
            <Input
              placeholder="Search"
              value={search}
              onChangeText={search => this.setState({search})}
            />
            <Button transparent onPress={this.onSearch}>
              <Icon name="search" />
            </Button>
          </Item>
          <SwipeListView
            refreshControl={
              <RefreshControl refreshing={loading} onRefresh={this.onRefresh} />
            }
            data={data}
            renderItem={({item}) => <RowTransactionSummary summary={item} />}
            leftOpenValue={75}
            rightOpenValue={-75}
            keyExtractor={summary => summary.name}
            onEndReached={this.onEndReached}
            onEndReachedThreshold={0.5}
          />
          <Fab onPress={this.onShowForm}>
            <Icon name="add" />
          </Fab>
        </View>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  data: state.transactionSummary.data,
  loading: state.transactionSummary.loading,
  error: state.transactionSummary.error,
});

const mapDispatchToProps = {
  findSummary,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(TransactionSummary);
