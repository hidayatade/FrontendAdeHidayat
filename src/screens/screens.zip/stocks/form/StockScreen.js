import React, {Component} from 'react';
import {
  Container,
  Text,
  Content,
  Form,
  Item,
  Input,
  Label,
  Button,
  Icon,
} from 'native-base';
import {View} from 'react-native';
import {CommonHeader} from '../../../components/CommonHeader';
import styles from './styles';
import {connect} from 'react-redux';
import {save, findById} from '../../../actions/stocks';
import {showError} from '../../../utils/toast';

class StockScreen extends Component {
  constructor(props) {
    super(props);

    const {route} = this.props;
    this.state = {
      id: route.params?.id,
      item: {},
      unit: {},
      quantity: 0,
    };
  }

  componentDidMount = () => {
    const {id} = this.state;
    if (id) {
      this.props.findById(this.state.id);
    }
  };

  componentDidUpdate(prevProps, prevState) {
    const {navigation, data, savedData, savedError, error} = this.props;
    console.log(this.state);
    if (prevProps.data !== data) {
      this.setState({...data});
    } else if (prevProps.savedData !== savedData) {
      navigation.goBack();
    } else if (error && prevProps.error !== error) {
      showError(error);
    } else if (savedError && prevProps.savedError !== savedError) {
      showError(savedError);
    }
  }

  onChangeItem = (item, value) => {
    this.setState({[item]: value});
  };

  onChangeUnit = (unit, value) => {
    this.setState({[unit]: value});
  };

  onChangeQuantity = (quantity, value) => {
    this.setState({[quantity]: value});
  };

  onPressItemSelect = () => {
    this.props.navigation.navigate('ItemPicker', {
      onGoBack: this.selectedItem,
    });
  };

  onPressUnitSelect = () => {
    this.props.navigation.navigate('UnitPicker', {
      onGoBack: this.selectedUnit,
    });
  };

  selectedItem = item => {
    this.setState({item: item});
  };

  selectedUnit = unit => {
    this.setState({unit: unit});
  };

  onSubmit = () => {
    console.log('submit');
    
    this.props.save(this.state);
    // console.log(this.state);
  };

  render() {
    const {navigation, loading, savedError} = this.props;
    const {id, item, unit, quantity} = this.state;
    const errorData = savedError?.data || {};

    return (
      <Container>
        <CommonHeader navigation={navigation} title="Stocks" />

        <Content>
          <Form>
            {id && (
              <Item floatingLabel>
                <Label>ID</Label>
                <Input style={styles.input} disabled value={id.toString()} />
              </Item>
            )}
            <View>
              <Item>
                <Text>Item</Text>
                <Input
                  style={styles.input}
                  value={item.name}
                  onChangeText={value => this.onChangeItem('item', value)}
                  disabled={loading}
                />
                <Button transparent onPress={this.onPressItemSelect}>
                  <Icon name="search" />
                </Button>
              </Item>
            </View>
            <View>
              <Item>
                <Label>Unit</Label>
                <Input
                  style={styles.input}
                  value={unit.name}
                  onChangeText={value => this.onChangeUnit('unit', value)}
                />
                <Button transparent onPress={this.onPressUnitSelect}>
                  <Icon name="search" />
                </Button>
              </Item>
            </View>
            <View>
              <Item>
                <Label>Quantity</Label>
                <Input
                  style={styles.input}
                  value={quantity.toString()}
                  onChangeText={value =>
                    this.onChangeQuantity('quantity', value)
                  }
                />
              </Item>
            </View>
            <Button
              rounded
              style={styles.button}
              onPress={this.onSubmit}
              disabled={loading}>
              <Text style={styles.buttonText}>S a v e</Text>
            </Button>
          </Form>
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  savedData: state.savedStock.data,
  savedError: state.savedStock.error,
  data: state.stockById.data,
  loading: state.stockById.loading || state.savedStock.loading,
  error: state.stockById.error,
});

const mapDispatchToProps = {
  save,
  findById,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(StockScreen);
