import React, {Component} from 'react';
import {
  Container,
  Text,
  Content,
  Form,
  Item,
  Input,
  Label,
  Button,
} from 'native-base';
import {View} from 'react-native';
import {CommonHeader} from '../../../components/CommonHeader';
import styles from './styles';
import {connect} from 'react-redux';
import {save, findById} from '../../../actions/units';
import {showError} from '../../../utils/toast';

class UnitScreen extends Component {
  constructor(props) {
    super(props);

    const {route} = this.props;
    this.state = {
      id: route.params?.id,
      name: '',
      description: '',
    };
  }

  componentDidMount = () => {
    const {id} = this.state;
    if (id) {
      this.props.findById(this.state.id);
    }
  };

  componentDidUpdate(prevProps, prevState) {
    const {navigation, data, savedData, savedError, error} = this.props;
    if (prevProps.data !== data) {
      this.setState({...data});
    } else if (prevProps.savedData !== savedData) {
      navigation.goBack();
    } else if (error && prevProps.error !== error) {
      showError(error);
    } else if (savedError && prevProps.savedError !== savedError) {
      showError(savedError);
    }
  }

  onChange = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  onSubmit = () => {
    this.props.save(this.state);
  };

  render() {
    const {navigation, loading, savedError} = this.props;
    const {id, name, description} = this.state;
    const errorData = savedError?.data || {};
    console.log(savedError);
    return (
      <Container>
        <CommonHeader navigation={navigation} title="Units" />

        <Content>
          <Form>
            {id && (
              <Item floatingLabel>
                <Label>ID</Label>
                <Input style={styles.input} disabled value={id.toString()} />
              </Item>
            )}
            <View>
              <Item floatingLabel error={errorData?.name != null}>
                <Label>Name</Label>
                <Input
                  style={styles.input}
                  value={name}
                  onChangeText={value => this.onChange('name', value)}
                />
              </Item>
              <Item floatingLabel error={errorData?.description != null}>
                <Label>Description</Label>
                <Input
                  style={styles.input}
                  value={description}
                  onChangeText={value => this.onChange('description', value)}
                />
              </Item>
              {errorData?.name && (
                <Text style={styles.error}>{errorData?.description[0]}</Text>
              )}
            </View>
            <Button
              rounded
              style={styles.button}
              onPress={this.onSubmit}
              disabled={loading}>
              <Text style={styles.buttonText}>Save</Text>
            </Button>
          </Form>
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  savedData: state.savedUnit.data,
  savedError: state.savedUnit.error,
  data: state.unitById.data,
  loading: state.unitById.loading || state.savedUnit.loading,
  error: state.unitById.error,
});

const mapDispatchToProps = {
  save,
  findById,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(UnitScreen);
